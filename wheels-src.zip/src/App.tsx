// src/App.tsx
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import Header from "@/components/header/Header";
import Footer from "@/components/Footer";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Onboarding from "./pages/Onboarding";
import You from "./pages/You";
import Profile from "./pages/Profile";
import Wheels from "./pages/Wheels";
import Wins from "./pages/Wins";
import Shop from "./pages/Shop";
import Social from "./pages/Social";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCanceled from "./pages/PaymentCanceled";
import Safety from "./pages/Safety";
import AdminDashboard from "./pages/AdminDashboard";

import ScrollToTop from "@/components/ScrollToTop";
import { ExpensesProvider } from "@/context/ExpensesContext";
import PamAssistant from "@/components/PamAssistant";  // ← updated path

const queryClient = new QueryClient();

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, isDevMode } = useAuth();
  return isAuthenticated || isDevMode ? <>{children}</> : <Navigate to="/auth" replace />;
};

const Main: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return <main className="flex-1 pt-[var(--header-height)]">{children}</main>;
};

function AppRoutes() {
  const { pathname } = useLocation();
  const hidePam = ["/", "/auth", "/onboarding"].includes(pathname);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <div className="flex w-full px-4 sm:px-6 lg:px-8 py-6 gap-6">
        <div className="flex-1 overflow-auto">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/onboarding" element={<Onboarding />} />

            <Route
              path="/you"
              element={
                <ProtectedRoute>
                  <Main>
                    <You />
                  </Main>
                </ProtectedRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <Main>
                    <Profile />
                  </Main>
                </ProtectedRoute>
              }
            />
            <Route path="/wheels" element={<Main><Wheels /></Main>} />
            <Route
              path="/wins"
              element={
                <ExpensesProvider>
                  <Main>
                    <Wins />
                  </Main>
                </ExpensesProvider>
              }
            />
            <Route path="/shop" element={<Main><Shop /></Main>} />
            <Route path="/social" element={<Main><Social /></Main>} />
            <Route path="/payment-success" element={<Main><PaymentSuccess /></Main>} />
            <Route path="/payment-canceled" element={<Main><PaymentCanceled /></Main>} />
            <Route
              path="/safety"
              element={
                <ProtectedRoute>
                  <Main>
                    <Safety />
                  </Main>
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <Main>
                    <AdminDashboard />
                  </Main>
                </ProtectedRoute>
              }
            />

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>

        {!hidePam && (
          <div className="hidden lg:block fixed right-0 top-0 h-full w-[300px]">
            <PamAssistant user={{ name: "User" }} />
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <ScrollToTop />
          <AppRoutes />
        </Router>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}
