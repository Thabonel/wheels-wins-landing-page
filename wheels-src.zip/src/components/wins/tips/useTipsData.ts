
import { tipCategories, leaderboardData } from "./mockData";

export function useTipsData() {
  return {
    tipCategories,
    leaderboardData
  };
}
